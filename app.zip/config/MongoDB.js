const MongoClient = require("mongodb").MongoClient;

function MongoDB() {
    this.connection = null;
}

MongoDB.prototype.createConnection = async function () {
    return await MongoClient.connect(
        'mongodb://192.168.99.101:27017/', 
        { useNewUrlParser: true, useUnifiedTopology: true }
    )
}

module.exports = MongoDB;